[![Build Status](https://api.travis-ci.org/CanSatKit/CanSatKitLibrary.svg?branch=master)](https://travis-ci.org/CanSatKit/CanSatKitLibrary#) [![Docs Status](https://readthedocs.org/projects/cansatkitlibrary/badge/)](https://cansatkitlibrary.readthedocs.io) 


Arduino Library for CanSatKit!

Documentation: https://cansatkitlibrary.readthedocs.io

[![Render](https://raw.githubusercontent.com/wiki/CanSatKit/CanSatKitLibrary/render.png)](https://raw.githubusercontent.com/wiki/CanSatKit/CanSatKitLibrary/render.png)

