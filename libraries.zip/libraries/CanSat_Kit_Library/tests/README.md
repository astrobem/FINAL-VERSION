Install ArduinoUnit library.

To use this test:
 - flash two boards - with first.ino and second.ino sketches
 - open serial console on the first board (flashed with first.ino)
 - open serial console on the second board (flashed with second.ino)
 - observe both outputs

Proper result is signalised by:
```Test summary: 7 passed, 0 failed, and 0 skipped, out of 7 test(s).```
Make sure all the test passed on both boards.